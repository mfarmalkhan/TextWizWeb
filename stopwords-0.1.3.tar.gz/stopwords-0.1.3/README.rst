===============================
stopwords
===============================

.. image:: https://img.shields.io/pypi/v/stopwords.svg
        :target: https://pypi.python.org/pypi/stopwords

.. image:: https://readthedocs.org/projects/stopwords/badge/?version=latest
        :target: https://readthedocs.org/projects/stopwords/?badge=latest
        :alt: Documentation Status

Stopwords removal 

* Free software: ISC license
* Documentation: https://stopwords.readthedocs.org.

This package was created for the content/website analyzer at http://www.qpi.io

Features
--------


Credits
---------

Based on:
https://github.com/Alir3z4/stop-words

Tested some functions from 
https://gist.github.com/glenbot/4684356